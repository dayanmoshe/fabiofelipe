# Backup estático de fabiofelipe.com.br

Snapshot público criado em 2026-08-14.

## Conteúdo incluído

- página inicial;
- 9 páginas de imóveis;
- 140 imagens/ícones/arquivos visuais;
- folha de estilos original;
- formulários adaptados para abrir uma conversa direta no WhatsApp;
- sitemap e robots.txt;
- HTML original, sem alterações, na pasta `originais`;
- inventário com URL, tamanho e SHA-256 de cada arquivo baixado.

Tamanho dos arquivos baixados: aproximadamente 11.2 MiB.

## Teste rápido em um computador ou Raspberry Pi

No diretório deste pacote, execute:

```sh
python3 -m http.server 8080 --directory site
```

Abra `http://localhost:8080` no navegador. Em outro aparelho da mesma rede, use
`http://IP_DO_RASPBERRY:8080`.

## Hospedagem permanente no Raspberry Pi 3+

O pacote contém `compose.yaml`, que usa Nginx e serve apenas arquivos estáticos.
Depois de instalar Docker e o plugin Compose:

```sh
docker compose up -d
```

O site ficará na porta 8080. Para disponibilizá-lo na internet, você ainda
precisará apontar o domínio e escolher uma destas opções:

1. Cloudflare Tunnel (recomendado para conexão residencial e CGNAT), sem abrir
   portas no roteador.
2. Redirecionamento das portas 80/443 no roteador, IP público e HTTPS.

O Raspberry Pi não é totalmente gratuito: consome energia, depende da sua
internet e fica indisponível quando faltar energia ou conexão. Uma hospedagem
estática gratuita como Cloudflare Pages, GitHub Pages ou Netlify costuma ser
mais simples e confiável para este tipo de site.

## Mudanças em relação ao site da BrokerLink

- O Google Analytics e o Meta Pixel presentes no site original foram retirados
  para não enviar dados ao identificador configurado pela plataforma.
- A solicitação de geolocalização foi desativada porque dependia de uma API da
  BrokerLink.
- Os formulários agora montam uma mensagem e abrem o WhatsApp de Fábio Felipe.
- O rodapé e os links institucionais da BrokerLink foram preservados como
  atribuição, mas os arquivos visuais usados nas páginas estão salvos localmente.

## Limitação importante

Este é um snapshot: novos imóveis e alterações feitas no painel da BrokerLink
não aparecem automaticamente. Para atualização contínua, será necessário um
novo painel/CMS ou repetir a exportação.

Antes de trocar o DNS, mantenha este backup e teste todas as páginas. Caso o
domínio esteja sob gestão da BrokerLink, confirme que você possui acesso ao
registrador e à zona DNS.
